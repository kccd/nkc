const db = require('../../dataModels');
(async () => {
  console.log(`正在修改首页设置...`);
  await db.SettingModel.updateOne({_id: 'home'}, {
    $set: {
      'c.latestOrder': 'releasePost'
    }
  })
  console.log(`完成`);
  process.exit(0);
})();