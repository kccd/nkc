const db = require('../../dataModels');
const homeSettings = require('../../defaultData/settings/home');
(async () => {
  console.log(`正在修改首页设置...`);
  await db.SettingModel.updateOne({_id: 'home'}, {
    $set: {
      'c.communityToppedThreadsId': homeSettings.c.communityToppedThreadsId,
      'c.homeBlocksId': homeSettings.c.homeBlocksId
    }
  })
  console.log(`完成`);
  process.exit(0);
})();