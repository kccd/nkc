function sleep(time) {
  return new Promise((resolve, reject) => {
    setTimeout(resolve, time);
  });
}

// console.log(1);
// sleep()
// .then(() => {
//   console.log(3);
// })
// .then(() => {
//   console.log(4);
//   throw new Error(123);
// })
// .then(() => {
//   console.log(5);
// })
// .catch(err => {
//   console.error(err);
// })
// .then(() => {
//   console.log(6);
// })
// console.log(2);

async function run() {
  try{
    console.log(`a`);
    await sleep(1000);
    console.log(`b`);
    await sleep(1000);
    console.log(`c`);
    await sleep(1000);
    console.log(`d`);
    throw new Error(232323)
  } catch(err) {
    console.error(err);
  }
}

run();