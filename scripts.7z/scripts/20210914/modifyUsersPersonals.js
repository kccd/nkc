//格式化用户认证信息
//添加默认投诉类型
const db = require('../../dataModels');

async function run() {
  //定义用户默认认证信息
  var authenticate = {
    card: {
      status: "unsubmit",
      message: "",
      expiryDate: null,
      attachments: []
    },
    video: {
      status: "unsubmit",
      message: "",
      expiryDate: null,
      code: "",
      attachments: []
    }
  }
  console.log(`正在处理用户身份认证信息...`);
  await db.UsersPersonalModel.updateMany({
    authenticate: {
      $exists: false
    }
  }, {
    $set: {
      authenticate
    }
  });
}


run()
.then(() => {
  console.log(`完成`);
  //必须延迟之后才能退出，不然不会执行上面的代码
  process.exit(1);
})
.catch(console.error);