//格式化用户基金结题消息发送
const db = require('../../dataModels');

async function run() {
    console.log(`开始操作数据...`);
    await db.SettingModel.updateOne({_id: 'library'}, {
      $set: {
        'c.libraryTip': {
          tipShow: '所有内容均为网友上传，如涉嫌侵犯您的权利，请通过举报或报告问题/投诉功能发送通知。',
          tipUpload: '严禁上传侵权内容。'
        }
      }
    })
}


run()
    .then(() => {
        console.log(`完成`);
        //必须延迟之后才能退出，不然不会执行上面的代码
        process.exit(1);
    })
    .catch(console.error);
