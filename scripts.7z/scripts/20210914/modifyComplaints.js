//添加默认投诉类型
const db = require('../../dataModels');

async function run() {
  console.log(`正在处理投诉记录...`);
  const complaintTypeLanguage = require('../../languages/zh_cn/complaintTypes.json');
  const types = await db.ComplaintTypeModel.find({});
  const typesObj = {};
  for(const type of types) {
    typesObj[type.type] = type._id;
  }
  for(let en in complaintTypeLanguage) {
    if(!complaintTypeLanguage.hasOwnProperty(en)) continue;
    const zh = complaintTypeLanguage[en];
    const id = typesObj[zh];
    await db.ComplaintModel.updateMany({
      reasonType: en
    }, {
      $set: {
        reasonTypeId: id
      }
    });
  }
}


run()
.then(() => {
  console.log(`完成`);
  process.exit(0);
})
.catch(console.error);