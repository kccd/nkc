//格式化用户基金结题消息发送
const db = require('../../dataModels');

async function run() {
  //定义用户默认用户是否发送结题系统提醒
  console.log(`正在处理基金申请表...`);
  await db.FundApplicationFormModel.updateMany({
    reminded: {
      $exists: false
    }
  }, {
    $set: {
      reminded: false
    }
  });
}


run()
.then(() => {
  console.log(`完成`);
  //必须延迟之后才能退出，不然不会执行上面的代码
  process.exit(1);
})
.catch(console.error);
