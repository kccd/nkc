//格式化用户基金结题消息发送
const db = require('../../dataModels');

async function run() {
  console.log(`开始操作数据...`);
  const result = await db.ResourceModel.find({}).updateMany({
    "disabled": {
      $exists: false
    }
  }, {
    $set: {
      disabled: false
    }
  });
  console.log(result)
}


run()
  .then(() => {
    console.log(`完成`);
    process.exit(1);
  })
  .catch(console.error);


function sleep(time) {
  return new Promise((resolve, reject) => {
    setTimeout(resolve, time);
  });
}