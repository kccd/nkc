const db = require('../../dataModels');
const {promises: fsPromises} = require("fs");
module.exports = async (props) => {
  const {
    modelName, threadCount = 20, fileType, limit = 1000
  } = props
  const {Eve} = require('node-threads-pool');
  console.log(`正在处理 ${fileType}...`);
  const Model = db[modelName];
  const errorFilePath = `./${fileType}_error.txt`;
  await fsPromises.writeFile(errorFilePath, '');
  const count = await Model.countDocuments();
  const tp = new Eve('./thread.js', threadCount);
  let completedThreadCount = 0;
  const taskCount = Math.ceil(count / limit);
  return new Promise((resolve) => {
    for(let i = 0; i < taskCount; i++) {
      const start = i * limit;
      const name = `${fileType} 总：${count} 当前：${start} - ${start + limit}`;
      tp.run({
        name,
        limit,
        start,
        modelName,
        errorFilePath
      })
        .then(res => {
          console.log(name + ` 完成`);
        })
        .catch(err => {
          console.log(err);
          console.error(name + ' 失败');
        })
        .finally(() => {
          completedThreadCount ++;
          if(completedThreadCount === taskCount) {
            console.log(`处理完成`);
            resolve();
          }
        })
    }
  });
}