const {Thread} = require('node-threads-pool');
const db = require("../../dataModels");
const {promises: fsPromises} = require("fs");

new Thread(async (data) => {
  const {limit, start, name, modelName, errorFilePath} = data;
  const Model = db[modelName];
  const resources = await Model.find({}).sort({toc: 1}).skip(start).limit(limit);
  for(let i = 0; i < resources.length; i++) {
    const resource = resources[i];
    const id = resource.rid || resource._id;
    try{
      await resource.updateFilesInfo();
    } catch(err) {
      await fsPromises.appendFile(errorFilePath, `id: ${id} error: ${err.message || err.toString()}\n`)
    }
    // console.log(name + ` ${i + 1}`);
  }
});