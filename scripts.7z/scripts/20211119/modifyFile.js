const main = require('./main');
const threadCount = 6;
const t = Date.now();
const func = async () => {
  await main({
    modelName: 'VerifiedUploadModel',
    fileType: 'verifiedUpload',
    limit: 100,
    threadCount,
  });
  await main({
    modelName: 'MessageFileModel',
    fileType: 'messageFile',
    limit: 100,
    threadCount,
  });
  await main({
    modelName: 'AttachmentModel',
    fileType: 'attachment',
    limit: 200,
    threadCount,
  });
  await main({
    modelName: 'ResourceModel',
    fileType: 'resource',
    limit: 200,
    threadCount,
  });

};

func()
  .then(() => {
    let time = Date.now() - t;
    time = Math.ceil(time / (60 * 1000));
    console.log(`完成 耗时 ${time} 分`);
    process.exit(0);
  })
  .catch(console.error)