const db = require('../../dataModels');
(async () => {
  console.log(`正在修改上传设置...`);
  await db.SettingModel.updateOne({_id: 'upload'}, {
    $set: {
      'c.watermark.picture.flex': 0.08,
      'c.watermark.video.flex': 0.2
    }
  })
  console.log(`完成`);
  process.exit(0);
})();