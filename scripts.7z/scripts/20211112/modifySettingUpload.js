const db = require('../../dataModels');
(async () => {
  const uploadSetting = await db.SettingModel.findOne({_id: 'upload'}, {enabled: 1, transparency: 1, minHeight: 1, minWidth: 1});
  console.log(`正在修改上传设置...`);
  await db.SettingModel.updateOne({_id: 'upload'}, {
    $set: {
      'c.watermark': {
        picture: uploadSetting,
        video: uploadSetting,
      }
    }
  })
  console.log(`完成`);
  process.exit(0);
})();