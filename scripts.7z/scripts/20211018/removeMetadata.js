const db = require("../../dataModels");
const FILE = require("../../nkcModules/file");
const fs = require('fs');
const {urlReg} = require('../../nkcModules/regExp');
const ff = require("fluent-ffmpeg");
const updated = [];
(async () => {
  console.log(`正在处理音频...`);
  const match = {
    mediaType: 'mediaAudio'
  };
  const count = await db.ResourceModel.countDocuments(match);
  const limit = 10000;
  for(let i = 0; i < count; i += limit) {
    console.log(`总：${count} 当前：${i} - ${i + limit}`);
    const resources = await db.ResourceModel.find(match).sort({toc: 1}).skip(i).limit(limit);
    for(const resource of resources) {
      //获取文件路劲
      const filePath = await resource.getFilePath();
      if(!await FILE.access(filePath)) continue;
      //获取文件信息
      const data = await getFileInfo(filePath);
      //文件标题信息
      const tags = data.format.tags || {};
      for(const key in tags) {
        if(!tags.hasOwnProperty(key)) continue;
        const value = tags[key];
        if(urlReg.test(value)) {
          const outputFilePath = filePath + '_out' + `.${resource.ext}`;
          await clearMetadata(filePath, outputFilePath);
          fs.unlinkSync(filePath);
          fs.renameSync(outputFilePath, filePath);
          updated.push({
            rid: resource.rid,
            path: filePath
          });
          break;
        }
      }
    }
  }
  fs.writeFileSync('./result.json', JSON.stringify(updated, '', 2));
  console.log(`完成`);
  process.exit(0);
})();


function getFileInfo(filePath) {
  return new Promise((resolve, reject) => {
    ff.ffprobe(filePath, (err, data) => {
      if(err) {
        reject(err);
      } else {
        resolve(data);
      }
    });
  });
}

function clearMetadata(filePath, outputFilePath) {
  return new Promise((resolve, reject) => {
    ff(filePath)
      .outputOptions([
        '-map_metadata',
        '-1',
        '-c:a',
        'copy'
      ])
      .output(outputFilePath)
      .on("end", resolve)
      .on("error", reject)
      .run();
  })
}