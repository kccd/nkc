const db = require('../../dataModels');
const downloadSettings = require('../../defaultData/settings/download');
(async () => {
  console.log(`正在修改下载设置...`);
  await db.SettingModel.updateOne({_id: 'download'}, {
    $set: {
      'c.visitorAccess': downloadSettings.c.visitorAccess
    }
  });
  console.log(`完成`);
  process.exit(0);
})();