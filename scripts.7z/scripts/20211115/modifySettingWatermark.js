const db = require('../../dataModels');
(async () => {
  console.log(`正在修改上传设置...`);
  const total = await db.UsersGeneralModel.find().countDocuments();
  const paging =Math.ceil(total/1000);
  for(let i = 0;i <= paging;i++) {
    console.log(i, paging);
    const userGenerals = await db.UsersGeneralModel.find({},{'waterSetting.waterGravity': 1, 'waterSetting.waterStyle': 1}).sort({_id: 1}).skip(i).limit(1000);
    for(const user of userGenerals) {
      await db.UsersGeneralModel.updateOne({
        uid: user.uid
      },{
        $set: {
          'waterSetting.picture': user.waterSetting,
          'waterSetting.video': user.waterSetting,
        }
      }).skip(i).limit(1000);
    }
  }
  console.log(`完成`);
  process.exit(0);
})();