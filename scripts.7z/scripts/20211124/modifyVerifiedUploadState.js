//格式化用户基金结题消息发送
const db = require('../../dataModels');

async function run() {
  //定义用户默认用户是否发送结题系统提醒
  console.log(`开始操作数据...`);
  const result = await db.VerifiedUploadModel.updateMany({
    state: {
      $exists: false
    }
  }, {
    $set: {
      state: 'usable'
    }
  });
}


run()
  .then(() => {
    console.log(`完成`);
    process.exit(1);
  })
  .catch(console.error);


function sleep(time) {
  return new Promise((resolve, reject) => {
    setTimeout(resolve, time);
  });
}